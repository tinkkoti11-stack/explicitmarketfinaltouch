import React, { useEffect, useRef } from 'react';

  export function MarketOverviewWidget() {
    const container = useRef<HTMLDivElement>(null);

    useEffect(() => {
      if (!container.current) return;
      const script = document.createElement("script");
      script.src = "https://s3.tradingview.com/external-embedding/embed-widget-market-overview.js";
      script.type = "text/javascript";
      script.async = true;
      script.innerHTML = JSON.stringify({
        "showChart": true,
        "locale": "en",
        "width": "100%",
        "height": "100%",
        "largeChartUrl": "",
        "gridLineColor": "rgba(42, 46, 57, 0)",
        "plotLineColorGrowing": "rgba(41, 98, 255, 1)",
        "plotLineColorFalling": "rgba(41, 98, 255, 1)",
        "gridLineColor": "rgba(42, 46, 57, 0)",
        "scaleFontColor": "rgba(134, 137, 147, 1)",
        "belowLineFillColorGrowing": "rgba(41, 98, 255, 0.12)",
        "belowLineFillColorFalling": "rgba(41, 98, 255, 0.12)",
        "belowLineFillColorGrowingBottom": "rgba(41, 98, 255, 0)",
        "belowLineFillColorFallingBottom": "rgba(41, 98, 255, 0)",
        "symbolActiveColor": "rgba(41, 98, 255, 0.12)",
        "tabs": [
          {
            "title": "Forex",
            "symbols": [
              { "s": "FX:EURUSD" }, { "s": "FX:GBPUSD" }, { "s": "FX:USDJPY" }, { "s": "FX:USDCHF" }, { "s": "FX:AUDUSD" }, { "s": "FX:USDCAD" }
            ]
          },
          {
            "title": "Indices",
            "symbols": [
              { "s": "FOREXCOM:SPX500" }, { "s": "FOREXCOM:NSXUSD" }, { "s": "FOREXCOM:DJI" }, { "s": "INDEX:NKY" }, { "s": "INDEX:DEU40" }
            ]
          },
          {
            "title": "Commodities",
            "symbols": [
              { "s": "CME_MINI:ES1!" }, { "s": "CME:6E1!" }, { "s": "COMEX:GC1!" }, { "s": "NYMEX:CL1!" }, { "s": "NYMEX:NG1!" }
            ]
          },
          {
            "title": "Crypto",
            "symbols": [
              { "s": "BINANCE:BTCUSDT" }, { "s": "BINANCE:ETHUSDT" }, { "s": "BINANCE:BNBUSDT" }, { "s": "BINANCE:SOLUSDT" }, { "s": "BINANCE:ADAUSDT" }
            ]
          }
        ],
        "colorTheme": "dark"
      });
      container.current.appendChild(script);
      return () => {
        if (container.current) {
          container.current.innerHTML = '';
        }
      };
    }, []);

    return (
      <div className="bg-[#0d1117] rounded-lg overflow-hidden flex flex-col h-full border border-[#21262d]">
        <div className="px-6 py-4 border-b border-[#21262d]">
          <h2 className="text-lg font-bold text-white">Live Market Overview</h2>
        </div>
        <div className="flex-1 min-h-[500px]" ref={container}>
          <div className="tradingview-widget-container__widget"></div>
        </div>
      </div>
    );
  }
  